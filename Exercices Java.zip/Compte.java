public class Compte{
    protected int solde;

    //CONSTRUCTEURS par defaut
    public Compte(){
        
    }

    //constructeur surchargé
    /*/public Compte(){

    }/*/

    //getters
    public int getSolde(){
        return solde;
    }

    //setters
    public void setSolde(int solde){
        this.solde=solde;
    }

    //Metiers
    public void affiche(){
        System.out.println("Solde: "+solde);
    }


}