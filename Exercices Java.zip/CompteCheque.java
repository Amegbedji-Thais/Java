public class CompteCheque extends Compte{
    private int frais=solde*taux;

    //constructeurs
    public CompteCheque(){
        super();
    }

    public CompteCheque(int frais){
        this.frais=frais;
    }

    //getters
    public int getFrais(){
        return frais;
    }

    //setters
    public void setFrais(int frais){
        this.frais=frais;
    }

    //metiers
    @Override
    public void afffiche(){
        super.affiche();
        System.out.println("Frais: "+frais);
    }
}