public class Enseignant extends Personne{
    private String grade;
    
    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public Enseignant(String prenom, String nom, String grade){
        super(prenom, nom);
        this.grade=grade;

    }

    @Override
    public String afficher(){
    return super.afficher() +"Grade: "+grade;
    }
}






