public class Epargne extends Compte{
    private static double taux=0.05;
    

    //constructeurs
    public Epargne(){
        super();
    }

    public Epargne(double taux){
        this.taux=taux;
    }

    //getters
    public double getTaux(){
        return taux;
    }

    //setters
    public void setTaux(double taux){
        this.taux=taux;
    }

    //metiers
    @Override
    public void affiche(){
        super.affiche();
        System.out.println("\nTaux: 5%");
    }
}