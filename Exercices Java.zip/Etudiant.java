import java.time.LocalDate; 
public class Etudiant extends Personne{
    private String enseignant;

    public String getEnseignant(){
        return enseignant;
    }

    public void setEnseignant(String enseignant) {
        this.enseignant = enseignant;
    }

    public Etudiant(String nom, String prenom, String enseignant, LocalDate dateNaiss){
        super( nom, prenom, dateNaiss) ;
    }
 
    @Override
    public String afficher(){
        return super.afficher() +"Enseignant: "+enseignant;
    }

}

