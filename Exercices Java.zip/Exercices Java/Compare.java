import java.util.Scanner;
class Compare{
    public static void main(String[] args) {
        Scanner compare=new Scanner(System.in);
        System.out.println("Entrez un premier entier");
        int x1=compare.nextInt();
        System.out.println("Entrez un deuxieme entier");
        int x2=compare.nextInt();
        if(x1<x2){
            System.out.print(x1);
            System.out.print(" est inferieur a ");
            System.out.println(x2);
        }
        else{
            System.out.print(x1);
            System.out.print(" est superieur a ");
            System.out.println(x2);
        }
    }
}
