import java.util.Scanner;
class Signe {
    public static void main(String[] args){
        Scanner signe=new Scanner(System.in);
        System.out.println("Entrez un entier");
        int nb=signe.nextInt();
        if (nb>0) {
            System.out.print("Positif");
        }
        else{
            System.out.print("Negatif");
        }
        
    }
}