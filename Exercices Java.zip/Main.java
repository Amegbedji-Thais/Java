class Main{
    public static void main(String[] args) {
        //declaration
        Compte c1=new Compte();
        c1.setSolde(10000);
        c1.affiche();

        Compte c2=new Compte();
        c2.setSolde(5000);
        c2.affiche();

        Epargne e=new Epargne("Taux: "+taux);
        e.affiche();

        CompteCheque cc=new CompteCheque("Frais: "+frais);
        cc.affiche();
    }
}