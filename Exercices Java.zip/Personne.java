 import java.time.LocalDate;

 public abstract class Personne{
    
    private int id;
    protected String prenom;
    protected String nom;
    protected LocalDate dateNaiss;
    private static int nbreDePersonne;

    public Personne(){
        nbreDePersonne++;
        id=nbreDePersonne;
    }
    
    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getNom(){
        return nom;
    }

    public void setNom(String nom){
        this.nom = nom;
    }
    public String getPrenom(){
        return prenom;
    }
    public String setPrenom(){
        this.prenom=prenom;
    }

    public LocalDate getDateNaiss(){
        return dateNaiss;
    }
    public LocalDate setDateNaiss(){
        this.dateNaiss=dateNaiss;
    }

        public String afficher(){
            return "ID: "+id+"Prenom: "+prenom+"Nom: "+nom ;
                
            }



}

